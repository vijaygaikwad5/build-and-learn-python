
# Session 3: Build a Web UI for Task Tracker with Flask

## Recap of Session 2: Python CLI App

In Session 2, we built a **command-line based Task Tracker** using Python.  
Key features included:
- CSV-based task storage
- Functions to add, list, complete, and delete tasks
- A simple interface using CLI arguments

We created a modular backend (`task_engine.py`) that we’ll now **reuse inside Flask** to create a browser-based interface.

---

## Objective of Session 3

In this session, we will convert our CLI Task Tracker into a **minimal Flask web app**.

We’ll:
- Keep the backend logic the same
- Build a simple HTML frontend with Flask
- Interact with tasks via browser

No fancy styling — just clean functionality using HTML, Python, and Jinja templates.

---

## Session Workflow

| Section | Topic                            | Description                                                                 |
|---------|----------------------------------|-----------------------------------------------------------------------------|
| 1       | [Getting Started with Flask](section1.md)      | Introduction to Flask, setup, run a basic app, understand app.py line-by-line. |
| 2       | [Route Variables](section2.md)               | Learn how to use dynamic segments in URL paths (`/<task_id>`) for user actions. |
| 3       | [Listing Tasks in Browser](section3.md)       | Use task_engine.py to display tasks via Flask. Reuse CSV logic in web context. |
| 4       | [Rendering with Jinja2](section4.md)          | Replace raw text with structured HTML using Jinja templating.                |
| 5       | [Adding Tasks with a Form](section5.md)       | Build a basic HTML form to add tasks using POST request.                     |
| 6       | [Completing & Deleting Tasks](section6.md)    | Handle `/complete/<id>` and `/delete/<id>` routes to update CSV.            |
| 7       | [Homepage Challenge](section7.md)             | Add interactive links for complete/delete next to each task on homepage.     |

---

## What’s Next?

In **Session 4**, we’ll convert the same logic into a **REST API** using **FastAPI**.  
This will allow the same app to work not just via browser — but also through tools like:
- Postman
- curl
- JavaScript frontend
- Mobile apps

We’ll discuss:
- API routes
- HTTP methods (GET, POST, PUT, DELETE)
- JSON handling
- FastAPI basics

---

All code and logic stays the same — we simply **change how the user interacts** with it.

Ready to explore Flask? Start with [Section 1 →](section1.md)


# 🧱 Section 1: Getting Started with Flask

## 📚 References
- [Flask Quickstart](https://flask.palletsprojects.com/en/stable/quickstart/)
- [Jinja Templating Docs](https://jinja.palletsprojects.com/en/stable/templates/)

---

## 🍕 Start With a Relatable Analogy

> “Imagine you run a pizza shop.

Customers walk in, place an order, and you serve them what they asked for — maybe a Margherita or a Pepperoni.

If you were a website, your shop is the **server**, and those orders are **requests** from users.”

**Flask is like the person behind the counter who:**
- listens to each request (like ‘I want the homepage’),
- knows what to do (serve an HTML page or send data),
- and gives the right response (a webpage, some data, etc).

---

## 🧩 What Is Flask, Technically?

Flask is a small Python **web framework** that helps you build web applications.

- It turns Python functions into web pages or APIs.
- It handles routes like `/home`, `/add-task`, etc.
- It lets you return HTML templates or JSON data.
- It doesn’t come with too many prebuilt parts — and that’s what makes it **simple, fast, and perfect for learning.**

---

## 🧪 Real Example: CLI vs Flask

In Session 2, we had:

🖥️ **CLI:**
```bash
python task_tracker.py add 1 "Buy milk"
```

🌐 **Flask (in browser):**
```
http://localhost:5000/add?task_id=1&title=Buy milk
```

The logic is the same. What changes is **how we interact** with the program.

- CLI: via terminal input  
- Flask: via browser, mouse clicks, and forms

---

## ⚙️ Install Flask

Before using Flask, you need to install it:
```bash
pip install flask
```

---

## 📦 Minimal Flask App in 4 Steps

```python
from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return "Hello, Flask!"

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
```

Then run:
```bash
python app.py
```

Open your browser and go to:  
`http://localhost:5000/` → You’ll see **Hello, Flask!**

---

## 🌐 Understanding host and port

- `host='0.0.0.0'`: This allows your app to be accessible **publicly** on any network interface. It’s like putting a signboard outside your pizza shop saying "Open for delivery."
- `port=5000`: This is the **door number** — where the browser knocks to reach your app.
- `debug=True`: This helps during development by **auto-restarting the app** when you save changes. No need to stop/start manually every time.

---

## 🧠 Line-by-Line Explanation of `app.py`

```python
from flask import Flask
```
📌 We're importing the `Flask` **class** from the `flask` package (which we installed using pip).

```python
app = Flask(__name__)
```
📌 This line creates your web app.  
🧠 **Analogy**: Like turning on the lights in your restaurant — now it’s ready to serve customers.

```python
@app.route("/")
def home():
```
📌 A **route** connects a URL (`/`) to a function (`home`).  
🧠 Analogy: Like saying “when someone walks into the front door, greet them with a message.”

📌 ❓ Is route name and function name required to match? **No.** This works too:

```python
@app.route("/home")
def welcome():
```

The function can be named anything. It just needs to return something.

```python
return "Hello, Flask!"
```
📌 This sends back a **response** to the browser.  
🧠 Analogy: Like the server saying: “Here’s your welcome drink!”

```python
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
```
📌 This is our **gatekeeper function** (you learned this in Session 1).  
It makes sure this file is being run directly — not imported.

🧠 Analogy: This is like saying, “If this is my restaurant script being run directly, open the doors and start serving customers.”

---

Ready for next section? Let me know if you want this script versioned inside the GitHub repo too.


# 🗂️ Flask Directory Structure Explained

This guide explains the typical structure of a Flask app using your Smart Task Tracker project as reference.

---

## 📁 Project Structure

```
my_flask_app/
├── app.py
├── task_engine.py
├── tasks.csv
├── templates/
│   ├── index.html
│   └── add.html
├── static/
│   ├── style.css
│   └── script.js
└── README.md
```

---

## 🧱 File & Folder Descriptions

### `app.py`
- Main Flask app entry point.
- Handles route definitions and connects user actions to logic.
- Think of it as the **controller** or the **manager**.

### `task_engine.py`
- Reusable Python module for task logic: add, list, complete, delete.
- Separates **business logic** from UI/routing.
- Can be used in both CLI and Flask apps.

### `tasks.csv`
- Data storage using CSV format (instead of a database).
- Stores task info: ID, title, status.

---

## 📂 `templates/`

Flask uses this folder to look for HTML files when rendering views using `render_template()`.

- `index.html`: Shows list of tasks
- `add.html`: Task submission form

🔧 Powered by **Jinja2** templating — allows embedding Python-like expressions in HTML:
```html
{% for task in tasks %}
  <li>{{ task.title }}</li>
{% endfor %}
```

---

## 📂 `static/`

Holds static assets:  
- CSS stylesheets (`style.css`)  
- JavaScript files (`script.js`)  
- Images (`logo.png`)

Flask serves these with:
```html
<link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
```

---

## 📝 `README.md`
- Markdown file describing the app, setup instructions, usage.
- Useful for GitHub or documentation.

---

## 🧠 Analogy: Flask as a Restaurant

| Part             | Analogy                |
|------------------|------------------------|
| `app.py`         | Restaurant manager     |
| `task_engine.py` | Kitchen / chef logic   |
| `templates/`     | Waiters and table setup |
| `static/`        | Decoration & utensils  |
| `tasks.csv`      | Recipe book (data)     |

---

## ✅ Best Practices

- Keep logic (like CSV ops) in separate modules.
- HTML always goes in `templates/`.
- CSS/JS/images go in `static/`.
- Organize by functionality, not just file type, as your project grows.

---

📚 **More Reading**
- [Flask Docs – Project Layout](https://flask.palletsprojects.com/en/latest/tutorial/layout/)
- [Jinja2 Templating](https://jinja.palletsprojects.com/en/stable/)

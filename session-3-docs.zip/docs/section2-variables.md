
# 🧱 Section 2: Variables in Flask Routes

## 🎯 Objective

In this section, we’ll learn how to pass **variables inside Flask routes**.  
This is critical because in our Smart Task Tracker app, we’ll use it to:
- Mark a task as complete (using task ID)
- Delete a task (using task ID)

---

## 👇 Basic Example: Passing a Variable to a Route

```python
@app.route("/hello/<name>")
def add(name):
    return f"Hello, {name}"
```

### 🔍 Explanation

- `@app.route("/hello/<name>")`: This tells Flask — if the user visits `/hello/sam`, grab the value `sam` and treat it as a variable called `name`.
- `def add(name)`: This function receives that `name` value as a parameter.
- `return f"Hello, {name}"`: This sends a dynamic response like `Hello, sam`.

---

## 💡 Analogy

Imagine your web app is a receptionist.
- If someone walks in and says: “I’m Sam.”
- The receptionist replies: “Hello, Sam!”

Flask is the receptionist. It listens to the URL path and responds with a personalized answer.

---

## 🔁 Why Is This Important for Us?

We’ll reuse this pattern when we:
- Mark a task as complete: `/complete/2` → pass task ID = 2
- Delete a task: `/delete/3` → pass task ID = 3

It allows us to build **dynamic routes** that handle different items based on user input.

---

## 🧪 Try It Yourself

Here’s a working `app.py`:

```python
from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return "Hello, Flask!"

@app.route("/hello/<name>")
def add(name):
    return f"Hello, {name}"

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
```

### ✅ Run It:

```bash
python app.py
```

Then open:

- [http://localhost:5000/hello/Alice](http://localhost:5000/hello/Alice)
- [http://localhost:5000/hello/Bob](http://localhost:5000/hello/Bob)

Each URL triggers a response with the value you passed in the URL.

---

## 📚 Additional Notes

- You can pass multiple variables like this:

```python
@app.route("/user/<username>/post/<int:post_id>")
def show_post(username, post_id):
    return f"{username} - Post #{post_id}"
```

- You can also define types:
  - `<int:id>` for integers
  - `<string:name>` (default)
  - `<float:price>`, `<path:filepath>`, etc.

More on this here: [Flask Variable Rules](https://flask.palletsprojects.com/en/latest/quickstart/#variable-rules)

---

Let’s now use this logic to complete and delete tasks in our real app in the next section.


# Section 3: Build the Application Homepage (List Tasks)

## Objective
Display the list of tasks on the browser homepage by reading from a CSV file using logic we already built in Session 2.

---

## Step 1: Start With a Hardcoded Task List

Let’s begin by showing some sample tasks without using the CSV. This helps verify our Flask setup is working.

```python
@app.route("/")
def home():
    tasks = [{'id': 1, 'title': 'Learn Python', 'completed': False},
             {'id': 2, 'title': 'Build Tracker', 'completed': False}]
    return f"Current Tasks: {tasks}"
```

When you run this and open `http://localhost:5000`, you’ll see the dictionary printed as raw text.

This is just a starting point — we want to replace this hardcoded list with real data from our CSV file.

---

## Step 2: Reuse Code From Session 2

Let’s integrate the logic we already wrote.

1. Copy the file `session2_task_tracker.py` into your current folder.
2. Rename it to `task_engine.py` — this is where we keep all task-related logic.
3. Inside `task_engine.py`, we update or confirm the `list_tasks()` function looks like this:

```python
def list_tasks():
    ensure_csv_exists()
    tasks = []
    with open(CSV_FILE, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            tasks.append(row)
    return tasks
```

This function:
- Makes sure the `tasks.csv` file exists.
- Reads each row from the file.
- Appends each task (as a dictionary) into the `tasks` list.
- Returns the list to whoever calls this function.

---

## Step 3: Use list_tasks() in Flask

Now modify your `app.py`:

```python
from flask import Flask
from task_engine import list_tasks

app = Flask(__name__)

@app.route("/")
def home():
    tasks = list_tasks()
    return f"Current Tasks: {tasks}"
```

Here we’re importing and calling the `list_tasks()` function. This gives us real task data from the CSV instead of a hardcoded list.

---

## Testing

1. Run `python app.py`
2. Visit `http://localhost:5000/`
3. You’ll see something like:
```
Current Tasks: [{'id': '1', 'title': 'Learn Python', 'completed': 'False'}, ...]
```

That means your tasks are successfully being pulled from the CSV file.

---

## Summary

You now have a working homepage in Flask that loads dynamic task data from a CSV file using logic from Session 2.

In the next section, we’ll make this prettier by using an HTML template instead of printing raw Python dictionaries.

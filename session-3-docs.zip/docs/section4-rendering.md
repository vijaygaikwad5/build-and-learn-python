
# Section 4: Rendering HTML with Jinja Templates

## Objective
Until now, we’ve shown our tasks in the browser as raw Python text. That’s fine for debugging — but not for real users.  
Now we’ll learn how to **render proper HTML content** in the browser using Flask’s built-in templating engine: Jinja2.

---

## Why HTML Rendering?

When building web applications, users expect well-structured, styled pages.  
Raw data dumps don’t cut it — we need to return HTML.

This is done in Flask using `render_template()`, which loads an HTML file and injects dynamic content into it using **Jinja2 templates**.

---

## Step 1: Create an HTML Template

Create a new folder in your Flask project called `templates`.  
Inside it, create a file called `home.html`.

Paste this code into it:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Task Tracker</title>
</head>
<body>
    <h1>Smart Task Tracker</h1>
    <ul>
        {% for task in tasks %}
        <li>
            {{ task.id }} - {{ task.title }} — {{ 'Done' if task.completed == 'True' else 'Pending' }}
        </li>
        {% endfor %}
    </ul>
</body>
</html>
```
## What is <ul> in HTML?

`<ul>` stands for **unordered list**. It creates a bulleted list in HTML.

Example:

```html
<ul>
  <li>Learn Python</li>
  <li>Build Flask App</li>
</ul>
```

This will display:
- Learn Python
- Build Flask App

Each `<li>` becomes a bullet point.

---

## What is `<li>` in HTML?

`<li>` stands for **list item**.

It must be placed inside:
- `<ul>`: unordered list (bullets)
- `<ol>`: ordered list (numbered)

Each `<li>` represents one entry in the list.

## Summary

| Tag     | Purpose                     |
|----------|------------------------------|
| `<ul>`   | Starts an unordered (bulleted) list |
| `<li>`   | Defines each item in the list       |
---

## What is Jinja2?

Jinja2 is a templating language that lets you embed logic into HTML.

### Key Features:
- Use `{{ variable }}` to display data
- Use `{% for ... %}` and `{% if ... %}` to add logic (like loops and conditions)

### Delimiters:
| Delimiter       | Purpose                                 |
|-----------------|------------------------------------------|
| `{{ variable }}` | Print a value into HTML                  |
| `{% ... %}`      | Control logic like loops or if-statements|
| `{# ... #}`      | Comments (not shown in output)           |

---

## Analogy

Think of Jinja like “mail merge.”  
You design a template (like a letter), and Python fills in the details for each user — name, task, etc.

---

## Step 2: Update app.py to Render HTML

In your `app.py`:

```python
from flask import Flask, render_template
from task_engine import list_tasks

app = Flask(__name__)

@app.route("/")
def home():
    tasks = list_tasks()
    return render_template("home.html", tasks=tasks)
```

Here, `render_template` looks inside the `templates/` folder for `home.html`, and passes in the variable `tasks`.

---

## Can You Pass More Variables?

Yes! You can pass as many as you want:

```python
return render_template("home.html", tasks=tasks, username="Alex", count=3)
```

Inside the template:
```html
<p>Welcome, {{ username }}. You have {{ count }} tasks.</p>
```

Jinja supports:
- Strings
- Integers
- Lists
- Dictionaries
- Booleans
- Any serializable object

---

## Summary

We now render real HTML pages and inject dynamic task data using Jinja2.

In the next section, we’ll allow users to **add new tasks** using a form.

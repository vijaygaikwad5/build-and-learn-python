
# Section 5: Add Task Functionality in Flask

## Objective
Enable users to add tasks through a **browser-based form**.  
This is the first time we send data **from browser to server** — using a `POST` request.

---

## Step 1: Create the HTML Form

We’ll use an HTML `<form>` that sends a POST request to our Flask route.

### add.html

```html
<!DOCTYPE html>
<html>
<head>
    <title>Add Task</title>
</head>
<body>
    <h1>Add Task</h1>
    <form method="POST">
        <label>Task ID:</label>
        <input type="text" name="id" required><br><br>
        <label>Title:</label>
        <input type="text" name="title" required><br><br>
        <button type="submit">Add Task</button>
    </form>
    <br>
    <a href="/">Back to Home</a>
</body>
</html>
```

### What does this form do?

- `method="POST"` means: When the user submits the form, the browser sends the form data to the server using an HTTP POST request.
- `<input type="text" name="id">`: Creates a textbox for task ID. The `name` attribute is important — Flask uses this to fetch the submitted value.
- `<input type="text" name="title">`: Another textbox, for the task title.
- `<button type="submit">`: A button that submits the form.
- `<a href="/">Back to Home</a>`: Provides a link back to the task list page.

---

## Step 2: Add the Flask Route to Handle the Form

In `app.py`:

```python
from flask import request, redirect, render_template

@app.route("/add", methods=["GET", "POST"])
def add():
    if request.method == "POST":
        task_id = request.form.get("id")
        title = request.form.get("title")
        if task_id and title:
            add_task(task_id, title)
        return redirect("/")
    return render_template("add.html")
```

---

## Explanation (Line by Line)

- `@app.route("/add", methods=["GET", "POST"])`:  
  This route handles both:
  - `GET`: When user opens the form page.
  - `POST`: When user submits the form.

- `if request.method == "POST"`:  
  Check if the request is a form submission.

- `request.form.get("id")`:  
  Fetches the value from the input field named `"id"`.

- `request.form.get("title")`:  
  Fetches the value from the input field named `"title"`.

- `if task_id and title:`  
  Only add the task if both fields are filled.

- `add_task(task_id, title)`:  
  Calls the function from `task_engine.py` to save the task in the CSV file.

---

## What Do the Two `return` Statements Do?

1. `return redirect("/")`  
   - Executed **after a task is submitted**.
   - Sends user back to the homepage.
   - Uses HTTP 302 redirect (temporary redirect).

2. `return render_template("add.html")`  
   - Executed **when user opens** the `/add` URL.
   - Shows the form (GET request).

---

## GET vs POST: Clarifying the Difference

| Request Type | When It Happens                | What It Does                               |
|--------------|--------------------------------|--------------------------------------------|
| GET          | When user opens the page       | Browser fetches and displays the form      |
| POST         | When user submits the form     | Browser sends form data to Flask backend   |

In our route:
- GET: Show the blank form.
- POST: Receive form data, save task, redirect to homepage.

---

## Summary

You’ve now added **user input via browser** to your app.

- We learned about HTML forms
- POST vs GET request handling
- Sending data to Flask using `request.form`
- Calling backend functions from UI

In the next section, we’ll let users complete or delete tasks with a single click.

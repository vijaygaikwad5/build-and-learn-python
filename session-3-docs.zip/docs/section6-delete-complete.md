
# Section 6: Configure the Delete and Complete Task Functions

## Objective
Allow users to mark a task as complete or delete it using browser links like:
- `/complete/1` → mark task with ID 1 as complete
- `/delete/1` → delete task with ID 1

---

## Background

In our CLI version of the app, we passed the action (`complete` or `delete`) along with the task ID as command-line arguments.

We’ll apply a similar logic in Flask using **route parameters**. These are parts of the URL that Flask can extract and use inside functions.

---

## Step 1: Add Routes for Complete and Delete

In your `app.py`, add the following routes:

```python
@app.route("/complete/<task_id>")
def complete(task_id):
    complete_task(task_id)
    return redirect("/")

@app.route("/delete/<task_id>")
def delete(task_id):
    delete_task(task_id)
    return redirect("/")
```

### Explanation

- `<task_id>`: This is a **variable part of the route**. If a user visits `/complete/2`, then `task_id` will be `"2"` inside the function.
- `complete_task()` and `delete_task()` are Python functions that we built in Session 2 — now reused here to work in a web context.
- `redirect("/")` tells Flask to **send the user back to the homepage** after the task is completed or deleted.

---

## What is `redirect()`?

`redirect()` is a Flask utility that issues a **302 redirect** — telling the browser to go to a new page.

### Syntax:
```python
redirect(location, code=302, Response=None)
```

- `location`: The URL to go to. In our case, it's the homepage (`/`).
- `code`: Optional. Defaults to `302`, which means temporary redirect.
- `Response`: You can optionally customize the response object returned.

---

## Step 2: Try It Out

1. Start the Flask app:
```bash
python app.py
```

2. Open your browser and visit:
- `http://localhost:5000/complete/1`
- `http://localhost:5000/delete/2`

3. After visiting each link:
- `complete/1`: The corresponding task in `tasks.csv` will be marked as completed.
- `delete/2`: The corresponding task will be removed from `tasks.csv`.

You’ll be redirected to the homepage and can visually confirm the updates.

---

## Summary

You now have a working Flask app that supports:
- Adding tasks through a form
- Viewing tasks from CSV
- Completing tasks with a route
- Deleting tasks with a route

In the next section, we’ll connect these actions directly into the homepage UI using clickable links.


# Section 7: Challenge – Add Action Links to Homepage

## Objective
Right now, completing or deleting a task requires manually typing `/complete/<id>` or `/delete/<id>` in the browser.

This challenge is to make your task list interactive — by adding **action links directly to each task** on the homepage.

---

## Step 1: Ask the Audience

Pose the question:

> "Instead of going to `/delete/2` or `/complete/2` manually, can we make it easier for the user?  
> What if we put these as clickable options right next to each task?"

Give the audience time to suggest ideas.

---

## Step 2: The Solution

We update the `home.html` file to include action links in each task row.

### Updated Template

```html
<!DOCTYPE html>
<html>
<head>
    <title>Task Tracker</title>
</head>
<body>
    <h1>Smart Task Tracker</h1>
    <a href="/add">Add New Task</a>
    <ul>
        {% for task in tasks %}
        <li>
            {{ task.id }} - {{ task.title }} — {{ 'Done' if task.completed == 'True' else 'Pending' }}
            [<a href="/complete/{{ task.id }}">Complete</a>]
            [<a href="/delete/{{ task.id }}">Delete</a>]
        </li>
        {% endfor %}
    </ul>
</body>
</html>
```

---

## Step 3: Detailed Explanation of Links

### Link 1:
```html
<a href="/complete/{{ task.id }}">Complete</a>
```

- `{{ task.id }}`: Inserts the task's actual ID into the URL.
- Example output:  
  If `task.id = 3`, then this becomes:  
  `<a href="/complete/3">Complete</a>`
- Clicking this link opens `/complete/3`, which triggers your Flask `@app.route("/complete/<task_id>")` function.

### Link 2:
```html
<a href="/delete/{{ task.id }}">Delete</a>
```

- Works exactly the same as the `Complete` link.
- If `task.id = 2`, this becomes:  
  `<a href="/delete/2">Delete</a>`

These links turn every row into a **clickable interface**, allowing users to manage tasks without typing any URL manually.

---

## Summary

You’ve just transformed your basic task list into an interactive UI:
- Each task has "Complete" and "Delete" options.
- These options are wired directly into your Flask backend via dynamic route links.
- It’s a big step toward building a polished web application experience.

Next steps could include:
- Adding confirmation popups before delete
- Styling the links into buttons
- Using color codes for task status
